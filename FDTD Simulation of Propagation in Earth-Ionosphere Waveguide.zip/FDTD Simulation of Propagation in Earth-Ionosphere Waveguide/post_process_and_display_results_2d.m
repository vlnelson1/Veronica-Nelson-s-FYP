disp('displaying simulation results');

display_transient_parameters_2d;
calculate_frequency_domain_outputs_2d;
display_frequency_domain_outputs_2d;
distances;
